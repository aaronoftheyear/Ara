# 🚀 Personal Anime Assistant - Setup Guide

This guide details how to set up the Personal Anime Assistant, which connects directly to the **MyAnimeList API** for live data.

## Step 1: Get API Credentials

You will need three pieces of information:

1.  **Google Gemini API Key**:
    *   Go to [AI Studio API keys](https://aistudio.google.com/app/apikey).
    *   Click **"Create new API key"**.
    *   Copy the key immediately and save it somewhere safe.

2.  **MyAnimeList (MAL) Client ID**:
    *   Log in to your [MyAnimeList Account](https://myanimelist.net).
    *   Go to the [API settings page](https://myanimelist.net/apiconfig) in your profile settings.
    *   Click **"Create ID"**.
    *   Fill out the application form. You can use placeholder details:
        *   App Name: `Personal AI Assistant`
        *   App Type: `Other`
        *   App Description: `A personal tool for getting anime recommendations.`
        *   App Redirect URL: `http://localhost:3000` (or any valid URL)
    *   Submit the form.
    *   Copy the **Client ID** from the new entry that appears.

3.  **Your MyAnimeList Username**: This is your public MAL username.

## Step 2: Configure the Project

1.  **Create an Environment File**: In the root directory of the project, create a file named `.env`.

2.  **Add Your Credentials**: Open the `.env` file and add your keys and username like this, replacing the placeholder text with your actual credentials:
    ```
    # .env file
    GEMINI_API_KEY="paste_your_gemini_api_key_here"
    MAL_CLIENT_ID="paste_your_mal_client_id_here"
    MAL_USERNAME="paste_your_mal_username_here"
    ```

## Step 3: Run the Application

1.  **Install Dependencies**: Open your terminal in the project folder and run:
    ```bash
    npm install
    ```
2.  **Start the Server**: Once installation is complete, run:
    ```bash
    npm run dev
    ```
3.  Open your web browser and go to `http://localhost:3000`. The application should load and begin syncing with your MAL account.

## Troubleshooting

### Issue: "MAL API: Connection Failed"
**Solutions:**
1.  **Check `.env` file**: Ensure `MAL_CLIENT_ID` and `MAL_USERNAME` are present, correct, and have no extra spaces.
2.  **Check Username**: Make sure the `MAL_USERNAME` is exactly your MAL username.
3.  **Check MAL API Status**: The MyAnimeList API could be temporarily down.

### Issue: "Generic recommendations" or "Doesn't seem to know my list"
**Solutions:**
1.  **Verify Data Sync**: Check the status indicator in the top-right corner. It should say "MAL API Synced" with a green light. If it failed, the AI won't have your data.
2.  **Ask a Direct Question**: Test the data connection by asking something like, "What did I rate Death Note?". If it can't answer, the data isn't loaded correctly.

---
**Status:** ✅ Ready for direct MyAnimeList API connection.
