import { GoogleGenAI, Type } from "@google/genai";
import type { AnimeRecommendation, Settings, AnimeEntry } from '../types';

let ai: GoogleGenAI | null = null;

export const initializeAi = (apiKey: string) => {
    if (!apiKey) {
        console.error("Attempted to initialize Gemini AI without an API key.");
        return;
    }
    ai = new GoogleGenAI({ apiKey });
};

const getAiClient = (): GoogleGenAI => {
    const apiKeyFromStorage = localStorage.getItem('GEMINI_API_KEY');
    if (!ai && apiKeyFromStorage) {
        initializeAi(apiKeyFromStorage);
    }
    if (!ai) {
        throw new Error("Gemini AI client is not initialized. An API key is required.");
    }
    return ai;
}

const createSystemInstruction = (settings: Settings, excludedTitles: string[], planToWatchTitles: string[], allUserAnime: AnimeEntry[]): string => `
You are a personal anime recommendation assistant. Your primary and most critical goal is to provide recommendations that the user has NOT seen before.

**CRITICAL INSTRUCTION: EXCLUSION LIST**
The following is a list of anime titles the user has already seen (completed, watching, on-hold, or dropped).
YOU ARE FORBIDDEN FROM RECOMMENDING ANY ANIME ON THIS LIST.

**EXCLUSION LIST (${excludedTitles.length} titles):**
${JSON.stringify(excludedTitles)}

**CRITICAL INSTRUCTION: FRANCHISE CHECK**
Before recommending ANY title, you must perform a franchise check against both the main EXCLUSION LIST and the 'PLAN TO WATCH' LIST below.
1.  Take the potential recommendation's title (e.g., "Fairy Tail Season 2").
2.  Scan the entire EXCLUSION LIST for any titles that are part of the same franchise (e.g., the exclusion list contains "Fairy Tail").
3.  If a franchise match is found in the EXCLUSION LIST, YOU MUST DISCARD the recommendation immediately. This is a non-negotiable rule.
4.  Recommending a different season or part of a franchise the user has already seen, put on hold, or dropped is a critical failure. For example, if "Attack on Titan" is on the exclusion list, you are forbidden from recommending "Attack on Titan Season 2".

**CRITICAL INSTRUCTION: 'PLAN TO WATCH' LIST AS A FILTER**
The user also has a 'Plan to Watch' list. This list MUST ALWAYS be used for franchise checking, regardless of other settings.
1.  **'Plan to Watch' List Contents (${planToWatchTitles.length} titles):** ${JSON.stringify(planToWatchTitles)}
2.  **Rule A (Franchise Check):** If a prequel/sequel of a 'Plan to Watch' title is on the main EXCLUSION LIST, do not recommend it.
3.  **Rule B (Chronology Check):** You are forbidden from recommending an earlier season of a show if a later season is already on this 'Plan to Watch' list (e.g., do not recommend "The Rising of the Shield Hero" if "The Rising of the Shield Hero Season 3" is on this list).

**USER-DEFINED RULES:**
1.  **SCORE THRESHOLD:** Only recommend anime with a MAL score of **${settings.minScore}** or higher.
2.  **RECOMMENDING FROM 'PLAN TO WATCH' LIST:** ${settings.recommendFromPTW ? "You ARE PERMITTED to recommend titles directly from the 'Plan to Watch' list if they are a good fit for the user's request. These titles should be considered equally with all other potential anime and not be given special priority." : "You ARE FORBIDDEN from recommending titles that are directly on the 'Plan to Watch' list. Use that list for filtering purposes only."}

**USER DATA QUERY CAPABILITY**
If the user asks for specific details about an anime on their list (e.g., their score or the date they finished it), you MUST use the comprehensive list below to find the answer. Access the specific entry and provide the requested information directly.

**USER'S FULL ANIME LIST (FOR DATA LOOKUP ONLY):**
${JSON.stringify(allUserAnime)}

**RESPONSE PROTOCOL:**
1.  Acknowledge the user's request.
2.  If the user is asking for a recommendation, select 2-3 titles based on their preferences and adhering strictly to all rules above.
3.  If the user is asking a question about their list, provide a direct answer based on the data.
4.  Provide a personalized 'reasoning' for each recommendation, ideally by comparing it to their known tastes if mentioned in the prompt.
5.  **TITLE FORMATTING:** You **MUST** use the most common English title for the anime in your response. For example, use "Attack on Titan", not "Shingeki no Kyojin". This is a strict requirement.
6.  Construct the final response in the specified JSON format. The 'responseText' should be a brief conversational intro or a direct answer to a question. If no recommendations are generated, the 'recommendations' array should be empty.
`;

const recommendationSchema = {
  type: Type.OBJECT,
  properties: {
    responseText: {
      type: Type.STRING,
      description: "A friendly, conversational, and direct introductory message for the recommendations, or a direct answer to the user's question.",
    },
    recommendations: {
      type: Type.ARRAY,
      description: "A list of structured anime recommendation objects based on the user's preferences and watch history. This should be an empty array if the user is asking a question rather than seeking recommendations.",
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "The most common English title of the anime. Do not use Romaji." },
          mal_score: { type: Type.NUMBER, description: "The MyAnimeList score for the anime." },
          genres: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of genres for the anime." },
          synopsis: { type: Type.STRING, description: "A brief synopsis of the anime." },
          reasoning: { type: Type.STRING, description: "A personalized reason why this anime is recommended for the user, based on their watch history." },
          has_dub: { type: Type.BOOLEAN, description: "Set to true if a well-known English dub is available for this anime, otherwise set to false." }
        },
        required: ["title", "mal_score", "genres", "synopsis", "reasoning", "has_dub"],
      },
    },
  },
  required: ["responseText", "recommendations"],
};

export const getAnimeRecommendation = async (
  userPrompt: string,
  settings: Settings,
  excludedTitles: string[],
  planToWatchTitles: string[],
  allUserAnime: AnimeEntry[]
): Promise<{ responseText: string; recommendations: AnimeRecommendation[] }> => {
  try {
    const aiClient = getAiClient();
    const systemInstruction = createSystemInstruction(settings, excludedTitles, planToWatchTitles, allUserAnime);
    const response = await aiClient.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: recommendationSchema,
        temperature: 0.3, 
      },
    });

    const jsonText = response.text.trim();
    const cleanedJsonText = jsonText.replace(/^```json\n|```$/g, '');
    const data = JSON.parse(cleanedJsonText);

    return {
      responseText: data.responseText,
      recommendations: data.recommendations || [],
    };
  } catch (error) {
    console.error("Error fetching recommendations:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    return {
      responseText: `I'm sorry, I ran into an issue while generating recommendations. It could be a temporary problem with the AI model or the data connection. Please try again in a moment.\n\n*Error details: ${errorMessage}*`,
      recommendations: [],
    };
  }
};