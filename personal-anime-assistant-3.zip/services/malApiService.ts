// This service is responsible for fetching and parsing user's MAL data directly from the MyAnimeList API.
import { AnimeEntry } from '../types';

// Helper to map MAL API status strings to our internal, more readable format.
const mapMalStatus = (status: string): AnimeEntry['status'] => {
    switch (status) {
        case 'watching':
            return 'Watching';
        case 'completed':
            return 'Completed';
        case 'on_hold':
            return 'On-Hold';
        case 'dropped':
            return 'Dropped';
        case 'plan_to_watch':
            return 'Plan to Watch';
        default:
            return undefined;
    }
}

export const fetchUserAnimeList = async (username: string, clientId: string): Promise<AnimeEntry[]> => {
    if (!clientId) {
        throw new Error("MyAnimeList Client ID is not configured.");
    }
    if (!username) {
        throw new Error("MyAnimeList Username is not configured.");
    }
    
    // A CORS proxy is used to bypass browser security restrictions (CORS policy)
    // that prevent the web app from directly calling the MyAnimeList API.
    const proxyUrl = 'https://corsproxy.io/?';
    const apiUrl = `https://api.myanimelist.net/v2/users/${username}/animelist`;

    let allAnime: AnimeEntry[] = [];
    // By explicitly requesting sub-fields for list_status, we guarantee the API returns them.
    let nextUrl: string | null = `${apiUrl}?fields=list_status{score,finish_date,status}&limit=1000&nsfw=true`;

    try {
        // The MAL API uses pagination, so we need to fetch all pages.
        while (nextUrl) {
            // Prepend the proxy to the request URL.
            const response = await fetch(proxyUrl + nextUrl, {
                headers: {
                    'X-MAL-CLIENT-ID': clientId
                }
            });

            if (!response.ok) {
                 const errorBody = await response.text();
                 throw new Error(`Failed to fetch from MAL API: ${response.status} ${response.statusText}. Response: ${errorBody}`);
            }

            const pageData = await response.json();
            
            const transformedData = pageData.data.map((item: any) => ({
                title: item.node.title,
                score: item.list_status.score === 0 ? undefined : item.list_status.score,
                finishDate: item.list_status.finish_date,
                status: mapMalStatus(item.list_status.status)
            }));
            
            allAnime = [...allAnime, ...transformedData];
            // The 'next' URL from the API will be the original URL, so the loop will automatically proxy it on the next iteration.
            nextUrl = pageData.paging?.next || null;
        }
        
        return allAnime.filter(entry => entry.title && entry.status);
    } catch (error) {
        console.error("Error fetching or parsing MAL API data:", error);
        // Re-throw the error to be caught by the UI component
        throw error;
    }
};

export const searchAnime = async (title: string, clientId: string): Promise<{ coverImage?: string; trailerUrl?: string; releaseYear?: string; malUrl?: string; }> => {
    if (!clientId) {
        console.warn("MyAnimeList Client ID is not configured for anime search.");
        return {};
    }

    const proxyUrl = 'https://corsproxy.io/?';
    const apiUrl = `https://api.myanimelist.net/v2/anime?q=${encodeURIComponent(title)}&limit=1&fields=id,main_picture,promotional_videos,start_date`;

    try {
        const response = await fetch(proxyUrl + apiUrl, {
            headers: { 'X-MAL-CLIENT-ID': clientId }
        });

        if (!response.ok) {
            console.error(`Failed to search for anime "${title}": ${response.status}`);
            return {};
        }

        const result = await response.json();
        const animeNode = result.data?.[0]?.node;

        if (!animeNode) {
            console.warn(`No search result found for anime: "${title}"`);
            return {};
        }

        const coverImage = animeNode.main_picture?.large || animeNode.main_picture?.medium;
        const trailerUrl = animeNode.promotional_videos?.[0]?.trailer?.url;
        const releaseYear = animeNode.start_date?.substring(0, 4);
        const malUrl = animeNode.id ? `https://myanimelist.net/anime/${animeNode.id}` : undefined;

        return { coverImage, trailerUrl, releaseYear, malUrl };

    } catch (error) {
        console.error(`Error during anime search for "${title}":`, error);
        return {};
    }
};