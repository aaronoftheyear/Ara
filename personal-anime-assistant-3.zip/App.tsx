import React, { useState, useCallback, useEffect, useRef } from 'react';
import ChatWindow from './components/ChatWindow';
import MessageInput from './components/MessageInput';
import SettingsPanel from './components/SettingsPanel';
import TransparencyPanel from './components/TransparencyPanel';
import SetupScreen from './components/SetupScreen';
import { getAnimeRecommendation, initializeAi } from './services/geminiService';
import { fetchUserAnimeList, searchAnime } from './services/malApiService';
import { getExcludedAnimeTitles, getPlanToWatchTitles, getAllUserAnimeEntries } from './data/malData';
import { MessageRole } from './types';
import type { ChatMessage, Settings, AnimeEntry } from './types';
import { AssistantIcon, EyeIcon, EyeSlashIcon, AdjustmentsIcon, ArrowPathIcon } from './components/icons';

const popularGenres = [ "Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Mystery", "Psychological", "Romance", "Sci-Fi", "Slice of Life", "Thriller"];
const defaultPrompts = [ "Recommend a psychological thriller.", "Anything good from my plan to watch?", "Find me a hidden gem.", "I want something similar to Steins;Gate."];

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(true);
  
  const [malUsername, setMalUsername] = useState<string>('');
  const [isClientIdConfigured, setIsClientIdConfigured] = useState(false);
  
  const [settings, setSettings] = useState<Settings>({
    minScore: 5.0,
    recommendFromPTW: true,
  });
  
  const excludedTitlesRef = useRef<string[]>([]);
  const planToWatchTitlesRef = useRef<string[]>([]);
  const allUserAnimeRef = useRef<AnimeEntry[]>([]);

  const [isTransparencyPanelOpen, setIsTransparencyPanelOpen] = useState(false);
  const [isSettingsPanelOpen, setIsSettingsPanelOpen] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [quickPrompts, setQuickPrompts] = useState<string[]>(defaultPrompts);

  const generateQuickPrompts = useCallback((userAnime: AnimeEntry[]) => {
    const randomGenre = popularGenres[Math.floor(Math.random() * popularGenres.length)];
    const highRatedCompleted = userAnime.filter(
        anime => anime.status === 'Completed' && (anime.score ?? 0) >= 8
    );
    
    let randomAnimeTitle = "Steins;Gate"; // Fallback
    if (highRatedCompleted.length > 0) {
        const randomAnime = highRatedCompleted[Math.floor(Math.random() * highRatedCompleted.length)];
        randomAnimeTitle = randomAnime.title;
    }

    const newPrompts = [
        `Recommend a ${randomGenre.toLowerCase()} anime.`,
        "Anything good from my plan to watch?",
        "Find me a hidden gem.",
        `I want something similar to ${randomAnimeTitle}.`
    ];
    setQuickPrompts(newPrompts);
  }, []);

  const loadData = useCallback(async (username?: string, clientId?: string) => {
    setIsDataLoading(true);
    setMessages([]);

    const finalUsername = username || process.env.MAL_USERNAME;
    const finalClientId = clientId || process.env.MAL_CLIENT_ID;

    if (!finalUsername || !finalClientId || !localStorage.getItem('GEMINI_API_KEY')) {
        setShowSetup(true);
        setIsDataLoading(false);
        return;
    }
    
    setShowSetup(false);
    setMalUsername(finalUsername);
    setIsClientIdConfigured(!!finalClientId);

    try {
      const allEntries = await fetchUserAnimeList(finalUsername, finalClientId);
      if (allEntries.length === 0) {
          throw new Error("No anime entries loaded. Your list might be empty, private, or credentials invalid.");
      }
      excludedTitlesRef.current = getExcludedAnimeTitles(allEntries);
      planToWatchTitlesRef.current = getPlanToWatchTitles(allEntries);
      allUserAnimeRef.current = getAllUserAnimeEntries(allEntries);
      generateQuickPrompts(allUserAnimeRef.current);

      setMessages([{
          role: MessageRole.ASSISTANT,
          content: `Hello! I've successfully connected to MAL as **${finalUsername}**. Your data is synced. How can I assist you?`
      }]);
    } catch (error) {
      console.error("Failed to load anime data from MAL API:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setShowSetup(true); // Show setup again on error
      setMessages([{
        role: MessageRole.ASSISTANT,
        content: `I'm sorry, but I failed to connect to the MyAnimeList API. Please check your credentials and try again.\n\n*Error details: ${errorMessage}*`
      }]);
    } finally {
      setIsDataLoading(false);
    }
  }, [generateQuickPrompts]);
  
  // Check for credentials on initial load
  useEffect(() => {
    const apiKey = process.env.GEMINI_API_KEY || localStorage.getItem('GEMINI_API_KEY');
    const malUser = process.env.MAL_USERNAME || localStorage.getItem('MAL_USERNAME');
    const malClient = process.env.MAL_CLIENT_ID || localStorage.getItem('MAL_CLIENT_ID');
    
    if (apiKey) {
      localStorage.setItem('GEMINI_API_KEY', apiKey);
      initializeAi(apiKey);
    }
    if (malUser && malClient) {
      localStorage.setItem('MAL_USERNAME', malUser);
      localStorage.setItem('MAL_CLIENT_ID', malClient);
      loadData(malUser, malClient);
    } else {
      setShowSetup(true);
      setIsDataLoading(false);
    }
  }, [loadData]);

  const handleSetupComplete = (username: string, clientId: string, apiKey: string) => {
      localStorage.setItem('MAL_USERNAME', username);
      localStorage.setItem('MAL_CLIENT_ID', clientId);
      localStorage.setItem('GEMINI_API_KEY', apiKey);
      initializeAi(apiKey);
      loadData(username, clientId);
  };

  const handleReset = () => {
    localStorage.removeItem('MAL_USERNAME');
    localStorage.removeItem('MAL_CLIENT_ID');
    localStorage.removeItem('GEMINI_API_KEY');
    setMessages([]);
    setShowSetup(true);
  };

  const handleSend = useCallback(async (userMessage: string) => {
    if (!userMessage.trim()) return;

    const newUserMessage: ChatMessage = {
      role: MessageRole.USER,
      content: userMessage,
    };
    setMessages(prev => [...prev, newUserMessage]);
    setIsLoading(true);

    try {
      const { responseText, recommendations } = await getAnimeRecommendation(userMessage, settings, excludedTitlesRef.current, planToWatchTitlesRef.current, allUserAnimeRef.current);
      
      const malClientId = localStorage.getItem('MAL_CLIENT_ID');
      let finalRecommendations = recommendations;

      if (recommendations.length > 0 && malClientId) {
        finalRecommendations = await Promise.all(
          recommendations.map(async (rec) => {
            const details = await searchAnime(rec.title, malClientId);
            return {
              ...rec,
              coverImage: details.coverImage,
              trailerUrl: details.trailerUrl,
              releaseYear: details.releaseYear,
              malUrl: details.malUrl,
            };
          })
        );
      }

      const assistantMessage: ChatMessage = {
        role: MessageRole.ASSISTANT,
        content: responseText,
        recommendations: finalRecommendations,
      };
      setMessages(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error(error);
      const errorMessage: ChatMessage = {
        role: MessageRole.ASSISTANT,
        content: "I'm having trouble retrieving recommendations right now. This might be a temporary issue with the AI model. Please try your request again in a few moments.",
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [settings]);

  const getDataStatus = () => {
    if (isDataLoading) {
        return { text: 'Syncing with MyAnimeList API...', color: 'text-yellow-300' };
    }
    if (allUserAnimeRef.current.length > 0) {
        return { text: `MAL API Synced (${allUserAnimeRef.current.length + planToWatchTitlesRef.current.length} entries)`, color: 'text-green-300' };
    }
    return { text: 'MAL API: Connection Failed', color: 'text-red-400' };
  };

  if (showSetup) {
      return <SetupScreen onSetupComplete={handleSetupComplete} initialMessage={messages[0]?.content} />;
  }

  const dataStatus = getDataStatus();

  return (
    <div
      className="h-screen w-screen flex flex-col bg-gray-900 text-gray-200 font-sans"
      style={{
        backgroundImage: 'radial-gradient(circle at top right, rgba(22, 78, 99, 0.3), transparent 40%), radial-gradient(circle at bottom left, rgba(56, 189, 248, 0.2), transparent 50%)',
      }}
    >
      <header className="flex items-center justify-between p-4 border-b border-gray-700/50 bg-gray-900/50 backdrop-blur-sm shadow-sm z-10">
        <div className="flex items-center">
          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg mr-4">
            <AssistantIcon className="w-6 h-6 text-white" />
          </div>
          <div>
              <h1 className="text-xl font-bold text-white">Personal Anime Assistant</h1>
              <p className="text-sm text-gray-400">Live Connection</p>
          </div>
        </div>
        <div className="flex items-center space-x-6">
            <div className="text-right">
                <p className="text-sm font-semibold text-cyan-300">{malUsername}</p>
                <p className={`text-xs font-medium ${isClientIdConfigured ? 'text-green-300' : 'text-red-400'}`}>
                    Client ID: {isClientIdConfigured ? 'Loaded' : 'Missing'}
                </p>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isDataLoading ? 'bg-yellow-400 animate-pulse' : allUserAnimeRef.current.length > 0 ? 'bg-green-400' : 'bg-red-500'}`}></div>
              <span className={`text-xs font-medium ${dataStatus.color}`}>{dataStatus.text}</span>
            </div>
            <button 
              onClick={() => setIsSettingsPanelOpen(prev => !prev)}
              className="p-2 rounded-full hover:bg-gray-700 transition-colors"
              aria-label={isSettingsPanelOpen ? "Hide settings" : "Show settings"}
            >
              <AdjustmentsIcon className={`w-5 h-5 ${isSettingsPanelOpen ? 'text-cyan-300' : 'text-gray-400'}`} />
            </button>
            <button 
              onClick={() => setIsTransparencyPanelOpen(prev => !prev)}
              className="p-2 rounded-full hover:bg-gray-700 transition-colors"
              aria-label={isTransparencyPanelOpen ? "Hide exclusion list" : "Show exclusion list"}
            >
              {isTransparencyPanelOpen ? <EyeSlashIcon className="w-5 h-5 text-cyan-300" /> : <EyeIcon className="w-5 h-5 text-gray-400" />}
            </button>
            <button
                onClick={handleReset}
                className="p-2 rounded-full hover:bg-gray-700 transition-colors"
                aria-label="Reset credentials"
            >
                <ArrowPathIcon className="w-5 h-5 text-gray-400 hover:text-cyan-300" />
            </button>
        </div>
      </header>
      
      {isTransparencyPanelOpen && <TransparencyPanel excludedTitles={excludedTitlesRef.current} />}
      {isSettingsPanelOpen && <SettingsPanel settings={settings} setSettings={setSettings} planToWatchCount={planToWatchTitlesRef.current.length} />}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <ChatWindow messages={messages} isLoading={isLoading} />
      </div>
      <MessageInput onSend={handleSend} isLoading={isLoading || isDataLoading} quickPrompts={quickPrompts} />
    </div>
  );
};

export default App;