# Personal Anime Assistant

AI-powered anime recommendation assistant with a direct, real-time connection to your MyAnimeList data via the official API. This assistant analyzes your complete watch history, ratings, and preferences to provide truly personalized anime recommendations.

## Features

- **Live MyAnimeList API Access**: Connects directly to your MAL account for up-to-the-second data.
- **Preference Analysis**: Analyzes your high-rated anime to understand your taste patterns.
- **Intelligent Filtering**: Guarantees you won't be recommended anime you've already seen, are watching, or have dropped.
- **Personalized Recommendations**: Tailors suggestions based on your actual ratings and genre preferences.
- **Data-Aware Queries**: Can answer specific questions about your list, like scores or completion dates.

## Setup Instructions

### 1. Prerequisites

- MyAnimeList account.
- Google account for Gemini AI.
- Node.js and npm installed.

### 2. Get API Credentials

1.  **Gemini API Key**: Go to [AI Studio](https://aistudio.google.com/app/apikey) to create and copy your API key.
2.  **MyAnimeList Client ID**:
    *   Log in to your [MyAnimeList Account](https://myanimelist.net).
    *   Go to your [API settings page](https://myanimelist.net/apiconfig).
    *   Click "Create ID" and fill out the form (app name, etc.). The "App Redirect URL" can usually be `http://localhost:3000`.
    *   Copy the **Client ID** that is generated.

### 3. Installation

1. Clone or download this project.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up environment variables. Create a `.env` file in the root of the project:
   ```
   # .env file
   GEMINI_API_KEY="your_gemini_api_key_here"
   MAL_CLIENT_ID="your_mal_client_id_here"
   MAL_USERNAME="your_mal_username_here"
   ```

### 4. Running the Application

```bash
npm run dev
```

## Usage

Interact with the assistant naturally.

**Analyze Preferences:**
`What are my top 3 favorite genres based on my high ratings?`

**Get Recommendations:**
`Recommend me a hidden gem.`

**Data Queries:**
`When did I finish watching Cowboy Bebop?`

**Find Similar Anime:**
`Recommend something like Attack on Titan.`

## Technical Details

### Architecture
```
User Input → Gemini API → MyAnimeList API → Personalized Response
```

### Key Components
- **`services/geminiService.ts`**: Handles AI API communication and prompt engineering.
- **`services/malApiService.ts`**: Fetches and parses data from the live MAL API.
- **`App.tsx`**: Main application interface and state management.
- **`components/`**: Reusable React components for the UI.
