export enum MessageRole {
  USER = 'user',
  ASSISTANT = 'assistant',
}

export interface AnimeEntry {
  title: string;
  score?: number;
  finishDate?: string; // YYYY-MM-DD
  status?: 'Completed' | 'Watching' | 'On-Hold' | 'Dropped' | 'Plan to Watch';
}

export interface AnimeRecommendation {
  title: string;
  mal_score: number;
  genres: string[];
  synopsis: string;
  reasoning: string;
  coverImage?: string;
  trailerUrl?: string;
  has_dub?: boolean;
  releaseYear?: string;
  malUrl?: string;
}

export interface ChatMessage {
  role: MessageRole;
  content: string;
  recommendations?: AnimeRecommendation[];
}

export interface Settings {
  minScore: number;
  recommendFromPTW: boolean;
}