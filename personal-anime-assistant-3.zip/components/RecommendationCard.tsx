import React from 'react';
import type { AnimeRecommendation } from '../types';
import { PlayIcon, InformationCircleIcon } from './icons';

interface RecommendationCardProps {
  recommendation: AnimeRecommendation;
}

const StarIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.007z" clipRule="evenodd" />
    </svg>
);

const RecommendationCard: React.FC<RecommendationCardProps> = ({ recommendation }) => {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:shadow-cyan-500/30 hover:ring-2 hover:ring-cyan-500/50 my-4 max-w-2xl flex">
      {recommendation.coverImage && (
        <img 
            src={recommendation.coverImage} 
            alt={`Cover for ${recommendation.title}`} 
            className="w-40 object-cover flex-shrink-0 bg-gray-700"
        />
      )}
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-cyan-300 pr-4">
            {recommendation.title}
            {recommendation.releaseYear && (
              <span className="text-gray-400 font-normal text-lg ml-2">({recommendation.releaseYear})</span>
            )}
          </h3>
          <div className="flex-shrink-0 flex items-center space-x-2">
            {recommendation.has_dub && (
              <span className="bg-blue-900 text-blue-200 px-2 py-1 rounded-full text-xs font-bold">
                DUB
              </span>
            )}
            <div className="flex items-center space-x-1 bg-gray-700 text-yellow-300 px-2 py-1 rounded-full text-sm font-semibold">
              <StarIcon className="w-4 h-4" />
              <span>{recommendation.mal_score.toFixed(2)}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {recommendation.genres.map((genre) => (
            <span key={genre} className="bg-gray-700 text-gray-300 text-xs font-medium px-2.5 py-0.5 rounded-full">
              {genre}
            </span>
          ))}
        </div>
        <p className="text-gray-400 text-sm mb-4 flex-grow">{recommendation.synopsis}</p>
        <div className="mt-auto">
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-gray-200 mb-1">Why you might like it:</h4>
            <p className="text-sm text-cyan-200 italic border-l-2 border-cyan-400 pl-3">
              "{recommendation.reasoning}"
            </p>
          </div>
          <div className="flex items-center gap-3">
            {recommendation.trailerUrl && (
              <a
                href={recommendation.trailerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-cyan-600 transition-colors font-semibold text-sm"
              >
                <PlayIcon className="w-4 h-4" />
                Watch Trailer
              </a>
            )}
            {recommendation.malUrl && (
                <a
                href={recommendation.malUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 text-gray-400 rounded-lg hover:bg-gray-700 hover:text-gray-200 transition-colors font-semibold text-sm"
              >
                <InformationCircleIcon className="w-4 h-4" />
                More Info
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecommendationCard;