import React from 'react';
import type { Settings } from '../types';

interface SettingsPanelProps {
  settings: Settings;
  setSettings: React.Dispatch<React.SetStateAction<Settings>>;
  planToWatchCount: number;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, setSettings, planToWatchCount }) => {
  return (
    <div className="bg-gray-800/60 p-4 border-b border-gray-700/50">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          
          <div className="md:col-span-1">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Minimum MAL Score: <span className="font-bold text-cyan-400">{settings.minScore.toFixed(1)}</span>
            </label>
            <input
              type="range"
              min="5.0"
              max="10.0"
              step="0.1"
              value={settings.minScore}
              onChange={(e) => setSettings(s => ({ ...s, minScore: parseFloat(e.target.value) }))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
          </div>

          <div className="md:col-span-1 flex items-center justify-center">
            <div className="flex items-center">
              <input
                id="ptw-checkbox"
                type="checkbox"
                checked={settings.recommendFromPTW}
                onChange={(e) => setSettings(s => ({ ...s, recommendFromPTW: e.target.checked }))}
                className="w-4 h-4 text-cyan-600 bg-gray-700 border-gray-600 rounded focus:ring-cyan-500"
              />
              <label htmlFor="ptw-checkbox" className="ml-2 text-sm font-medium text-gray-300">
                Include 'Plan to Watch' list <span className="text-gray-400">({planToWatchCount} entries)</span>
              </label>
            </div>
          </div>

          <div className="md:col-span-1">
             <label className="block text-sm font-medium text-gray-300 mb-2 text-center md:text-left">
              Hard Filters (Always Active)
            </label>
            <div className="flex justify-center md:justify-start flex-wrap gap-2">
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-red-900 text-red-300 opacity-75">Completed</span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-yellow-900 text-yellow-300 opacity-75">On Hold</span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-blue-900 text-blue-300 opacity-75">Watching</span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-gray-700 text-gray-300 opacity-75">Dropped</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;