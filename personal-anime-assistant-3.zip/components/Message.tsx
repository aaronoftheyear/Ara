
import React from 'react';
import { MessageRole } from '../types';
import type { ChatMessage } from '../types';
import { UserIcon, AssistantIcon } from './icons';
import RecommendationCard from './RecommendationCard';
import LoadingSpinner from './LoadingSpinner';

interface MessageProps {
  message: ChatMessage;
  isLoading?: boolean;
}

const renderWithBold = (text: string) => {
  if (!text) return null;
  const parts = text.split(/(\*\*.*?\*\*)/g);
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={index}>{part.slice(2, -2)}</strong>;
    }
    return part;
  });
};

const Message: React.FC<MessageProps> = ({ message, isLoading = false }) => {
  const isUser = message.role === MessageRole.USER;

  return (
    <div className={`flex items-start gap-4 my-6 ${isUser ? 'justify-end' : ''}`}>
      {!isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg">
          <AssistantIcon className="w-6 h-6 text-white" />
        </div>
      )}

      <div className={`max-w-2xl ${isUser ? 'order-1' : 'order-2'}`}>
        <div
          className={`px-5 py-3 rounded-2xl shadow-md ${
            isUser
              ? 'bg-blue-600 text-white rounded-br-none'
              : 'bg-gray-700 text-gray-200 rounded-bl-none'
          }`}
        >
          {isLoading ? <LoadingSpinner /> : <p className="whitespace-pre-wrap">{isUser ? message.content : renderWithBold(message.content)}</p>}
        </div>
        {!isUser && message.recommendations && message.recommendations.length > 0 && !isLoading && (
          <div className="mt-4">
            {message.recommendations.map((rec) => (
              <RecommendationCard key={rec.title} recommendation={rec} />
            ))}
          </div>
        )}
      </div>

      {isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-600 flex items-center justify-center shadow-lg order-2">
          <UserIcon className="w-6 h-6 text-gray-300" />
        </div>
      )}
    </div>
  );
};

export default Message;
