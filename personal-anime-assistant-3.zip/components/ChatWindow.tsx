
import React, { useRef, useEffect } from 'react';
import Message from './Message';
import type { ChatMessage } from '../types';
import { MessageRole } from '../types';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
      {messages.map((msg, index) => (
        <Message key={index} message={msg} />
      ))}
      {isLoading && (
        <Message message={{ role: MessageRole.ASSISTANT, content: '' }} isLoading={true} />
      )}
    </div>
  );
};

export default ChatWindow;
